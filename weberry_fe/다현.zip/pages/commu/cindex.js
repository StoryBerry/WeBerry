import React from 'react'
import Body from '../../components/Main/Body/Body'
import styles from '../../styles/Home.module.css'
import Cmain from '../../components/Commu/Cmain'

const cindex = () => {
  return (
    <>
  <div className={styles.container}>
       <div>
        < Cmain />
       </div>
      
    </div>
    </>
  )
}

export default cindex