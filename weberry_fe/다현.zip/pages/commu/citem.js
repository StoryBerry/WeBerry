import React from 'react'
import CommuItem from '../../components/Commu/CommuItem'
import styles from '../../styles/Home.module.css'


const citem = () => {
  return (
    <>
    <div className={styles.main}>
    <CommuItem />
    </div>
    </>
    )
}

export default citem