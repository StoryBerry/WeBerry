import React, {useState} from 'react'
import CommuList from './CommuList'



const Cmain = () => {
  return (
    <>
    <div className= 'pt-5 text-sm mt-20 justify-center items-center '>
       <CommuList />
    {/* {Board.map(BoardItem =>( */}
      {/* <img src={img}/> */}
      {/* // <h3>{}</h3>
      // <p>{}</p>
    ))} */}

    
    </div>
    </>
  
  )
}

export default Cmain