import React from 'react'

export const Main = () => {
  return (
    <div className='text-5xl'>메인입니다!!!! </div>
  )
}
export default Main