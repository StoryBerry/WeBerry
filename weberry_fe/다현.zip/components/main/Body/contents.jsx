import React from 'react'

export default function contents() {
  return (
    <div>contents</div>
  )
}
